import psycopg2
import random
import time
from datetime import datetime

# -----------------------------
# PostgreSQL Connection
# -----------------------------
try:
    conn = psycopg2.connect(
        dbname="orders_db",
        user="admin",
        password="admin",
        host="localhost",
        port=5432
    )
    cur = conn.cursor()
    print("✅ Connected to PostgreSQL successfully!")
except Exception as e:
    print("❌ Failed to connect to PostgreSQL:")
    print(e)
    exit()

# -----------------------------
# Sample Data
# -----------------------------
products = ["Laptop", "Mouse", "Keyboard", "Phone", "Monitor"]

# -----------------------------
# Insert Function
# -----------------------------
def insert_order():

    # ✅ FIXED: Unique ID generation (prevents duplicates on restart)
    #order_id = int(time.time() * 1000) + random.randint(0, 999)

    customer_id = random.randint(1, 200)
    product_name = random.choice(products)
    quantity = random.randint(1, 5)
    unit_price = random.randint(100, 1000)
    order_time = datetime.now()

    try:
        cur.execute("""
            INSERT INTO orders (
                customer_id, product_name,
                quantity, unit_price, order_time
            )
            VALUES (%s, %s, %s, %s, %s)
        """, (customer_id, product_name, quantity, unit_price, order_time))

        conn.commit()

    except Exception as e:
        print(f"❌ Error inserting order: {e}")
        conn.rollback()

# -----------------------------
# Data Generation Loop
# -----------------------------
print("🚀 Starting data generation...")

for i in range(5000):
    insert_order()

    # Progress logging
    if i % 500 == 0:
        print(f"📦 {i} records inserted...")

    time.sleep(0.05)

print("🎉 5000 orders inserted successfully!")

# -----------------------------
# Close connection
# -----------------------------
cur.close()
conn.close()
print("🔒 PostgreSQL connection closed.")