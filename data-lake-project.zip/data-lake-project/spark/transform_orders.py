import os

# ==================================================
# WINDOWS + HADOOP FIXES
# ==================================================
os.environ["HADOOP_HOME"] = r"C:\hadoop"
os.environ["hadoop.home.dir"] = r"C:\hadoop"
os.environ["PATH"] += r";C:\hadoop\bin"
os.environ["SPARK_LOCAL_IP"] = "127.0.0.1"


# ==================================================
# IMPORTS
# ==================================================
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim, initcap, year, month, from_unixtime
from pyspark.sql.types import DoubleType


# ==================================================
# SPARK SESSION
# ==================================================
spark = (
    SparkSession.builder
    .appName("Orders Transformation")

    .config(
        "spark.jars.packages",
        "org.apache.hadoop:hadoop-aws:3.3.4,"
        "com.amazonaws:aws-java-sdk-bundle:1.12.262"
    )

    # S3 / MINIO CONFIG
    .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000")
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.path.style.access", "true")
    .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")
    .config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")

    # 👇 ADD THIS LINE HERE
    .config(
        "spark.hadoop.fs.s3a.aws.credentials.provider",
        "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
    )

    # WINDOWS FIXES (VERY IMPORTANT)
    .config("spark.hadoop.io.native.lib.available", "false")
    .config("spark.local.dir", r"C:\spark-temp")

    .getOrCreate()
)

print("✅ Spark Session Created Successfully")


# ==================================================
# READ RAW DATA
# ==================================================
raw_path = "s3a://datalake/raw/postgres.public.orders/"
df = spark.read.json(raw_path)

print("\nRAW DATA SCHEMA")
df.printSchema()


# ==================================================
# FILTER VALID RECORDS
# ==================================================
df = df.filter(col("after").isNotNull())


# ==================================================
# FLATTEN STRUCTURE
# ==================================================
df_clean = df.select(
    col("after.order_id").alias("order_id"),
    col("after.customer_id").alias("customer_id"),
    col("after.product_name").alias("product_name"),
    col("after.quantity").alias("quantity"),
    col("after.unit_price").cast(DoubleType()).alias("unit_price"),
    col("after.order_time").alias("order_time")
)


# ==================================================
# CLEAN DATA
# ==================================================
df_clean = df_clean.filter(col("quantity") > 0)

df_clean = df_clean.withColumn(
    "product_name",
    initcap(trim(col("product_name")))
)


# ==================================================
# CALCULATIONS
# ==================================================
df_clean = df_clean.withColumn(
    "total_amount",
    col("quantity") * col("unit_price")
)


# ==================================================
# TIMESTAMP CONVERSION
# ==================================================
df_clean = df_clean.withColumn(
    "order_timestamp",
    from_unixtime(col("order_time") / 1000000)
)


# ==================================================
# PARTITION COLUMNS
# ==================================================
df_clean = df_clean.withColumn("year", year(col("order_timestamp"))) \
                   .withColumn("month", month(col("order_timestamp")))


# ==================================================
# PREVIEW
# ==================================================
print("\nTRANSFORMED DATA SAMPLE")
df_clean.show(10, truncate=False)


# ==================================================
# WRITE TO CURATED ZONE
# ==================================================
output_path = "s3a://datalake/curated/orders/"

df_clean.write \
    .mode("overwrite") \
    .option("mergeSchema", "true") \
    .partitionBy("year", "month") \
    .parquet(output_path)

print("\n✅ Curated Zone Created Successfully")


# ==================================================
# STOP SPARK
# ==================================================
spark.stop()