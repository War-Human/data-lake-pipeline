CREATE TABLE IF NOT EXISTS public.orders (
    order_id SERIAL PRIMARY KEY,
    customer_id BIGINT,
    product_name VARCHAR(100),
    quantity INT,
    unit_price NUMERIC(10,2),
    order_time TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.events (
    id SERIAL PRIMARY KEY,
    user_id INT,
    event VARCHAR(50),
    amount FLOAT,
    timestamp TIMESTAMP
);