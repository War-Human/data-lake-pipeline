from pyspark.sql import SparkSession
from pyspark.sql.functions import sum, desc

spark = (
    SparkSession.builder
    .appName("Order Analytics")

    .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000")
    .config("spark.hadoop.fs.s3a.access.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.secret.key", "minioadmin")
    .config("spark.hadoop.fs.s3a.path.style.access", "true")
    .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")

    # IMPORTANT
    .config("spark.hadoop.fs.s3a.impl",
            "org.apache.hadoop.fs.s3a.S3AFileSystem")

    .config(
        "spark.hadoop.fs.s3a.aws.credentials.provider",
        "org.apache.hadoop.fs.s3a.SimpleAWSCredentialsProvider"
    )

    .getOrCreate()
)
# -----------------------------
# Read CURATED DATA
# -----------------------------
df = spark.read.parquet("s3a://datalake/curated/orders/")

df.show(5)

# -----------------------------
# 1. Revenue by Product
# -----------------------------
product_revenue = df.groupBy("product_name") \
    .agg(sum("total_amount").alias("revenue")) \
    .orderBy(desc("revenue"))

product_revenue.show()

product_revenue.write.mode("overwrite") \
    .csv("s3a://datalake/analytics/revenue_by_product/")

# -----------------------------
# 2. Top Customers
# -----------------------------
customer_revenue = df.groupBy("customer_id") \
    .agg(sum("total_amount").alias("revenue")) \
    .orderBy(desc("revenue"))

customer_revenue.show()

customer_revenue.write.mode("overwrite") \
    .csv("s3a://datalake/analytics/top_customers/")